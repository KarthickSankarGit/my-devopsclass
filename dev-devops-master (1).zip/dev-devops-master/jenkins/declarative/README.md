# helloworld-declarative pipeline 👇👇



# steps :

1. Navigate to the Jenkins home page. Create a new Job and select Pipeline.
2. Now configure the project with valid description.
3. Now, navigate to the Pipeline section to write the groovy pipeline code. (use jenkins_File)
4. Click on Save and then build now.
5. Let's see the output.
