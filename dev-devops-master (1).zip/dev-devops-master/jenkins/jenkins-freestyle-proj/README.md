# freestyle jenkins project -1 😎👇
===========================================

# 1. install jenkins on ubuntu

apt update

apt install fontconfig openjdk-17-jre -y

<go to jenkins.io => copy binary file & key file>

apt update

apt install jenkins -y

systemctl enable --now jenkins


# 2. for connect jenkins

copy server public-ip:8080

cat /var/lib/jenkins/secrets/initialadminpassword

install suggested plug-ins


# 3. start nodeapp project

goto jenkins dashboard

click create new item

define your project name

select freestyle project

mention github project section : your github repo url

build now✌️✌️✌️✌️
